package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Bank_DB;

@WebServlet("/SpecificBalance")
public class SpecificBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SpecificBalance() {
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = (int)request.getSession().getAttribute("id");
		int aid = Integer.parseInt(request.getParameter("aid"));
		String type = request.getParameter("type");
		Bank_DB bankDB = new Bank_DB();
		request.setAttribute("specific", bankDB.getBalance(aid, type));
		request.setAttribute("transactions", bankDB.getTransactions(id, aid, type));
		bankDB.close();
		request.getRequestDispatcher("/AccountActivity.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
