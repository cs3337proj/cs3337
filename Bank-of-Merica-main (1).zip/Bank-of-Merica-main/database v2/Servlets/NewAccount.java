package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Bank_DB;

@WebServlet("/NewAccount")
public class NewAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public NewAccount() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int id = (int)request.getSession().getAttribute("id");
			Bank_DB bankDB = new Bank_DB();
			request.setAttribute("accounts", bankDB.getBalances(id));
			bankDB.close();
			request.getRequestDispatcher("NewAccount.jsp").forward(request, response);
		} catch (Exception e) {
			request.getRequestDispatcher("Login.jsp").forward(request, response);
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String newType = request.getParameter("new");
		String type = (String)request.getParameter("oldType");
		String[] parameters = type.split(",");
		int id = (int)request.getSession().getAttribute("id");
		int aid = Integer.parseInt(parameters[0]);
		String oldType = parameters[1];
		Bank_DB bankDB = new Bank_DB();
		bankDB.addBalance(id, aid, oldType, newType);
		bankDB.close();
		request.getRequestDispatcher("GetBalances").forward(request, response);
	}

}
