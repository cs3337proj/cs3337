package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Bank_DB;

@WebServlet("/AddAccount")
public class AddAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddAccount() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zip = request.getParameter("zip");
		String phone = request.getParameter("phone");
		String ssn = request.getParameter("ssn");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String repeatedPassword = request.getParameter("repeatedPassword");
		Bank_DB bankDB = new Bank_DB();
		if (password.equals(repeatedPassword) == false) {
			bankDB.close();
			oldInputs(request, response, firstname, lastname, address, city, state, zip, phone, ssn, username);
			request.getRequestDispatcher("Register.jsp").forward(request, response);
		} else if (bankDB.checkUsername(username) == true) {
			bankDB.close();
			oldInputs(request, response, firstname, lastname, address, city, state, zip, phone, ssn, username);
			request.getRequestDispatcher("Register.jsp").forward(request, response);
		} else {
			int id = bankDB.addAccount(firstname, lastname, address, city, state, zip, phone, ssn, username, password);
			bankDB.close();
			request.getSession().setAttribute("id", id);
			request.getRequestDispatcher("GetBalances").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected void oldInputs(HttpServletRequest request, HttpServletResponse response,
			String firstname, String lastname, String address, String city, String state, 
			String zip, String phone, String ssn, String username) throws ServletException, IOException {
		request.setAttribute("firstname", firstname);
		request.setAttribute("lastname", lastname);
		request.setAttribute("address", address);
		request.setAttribute("city", city);
		request.setAttribute("state", state);
		request.setAttribute("zip", zip);
		request.setAttribute("phone", phone);
		request.setAttribute("ssn", ssn);
		request.setAttribute("username", username);
	}

}
