package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Bank_DB;

/**
 * Servlet implementation class GetInformation
 */
@WebServlet("/UpdateInformation")
public class UpdateInformation extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UpdateInformation() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = (int)request.getSession().getAttribute("id");
		Bank_DB bankDB = new Bank_DB();
		request.setAttribute("information", bankDB.getInformation(id));
		bankDB.close();
		request.getRequestDispatcher("UpdateUserInfo.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = (int)request.getSession().getAttribute("id");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zip = request.getParameter("zip");
		String phone = request.getParameter("phone");
		Bank_DB bankDB = new Bank_DB();
		bankDB.updateInformation(id, firstname, lastname, address, city, state, zip, phone);
		bankDB.close();
		request.getRequestDispatcher("GetBalances").forward(request, response);
	}

}
