package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Bank_DB;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Login() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Bank_DB bankDB = new Bank_DB();
		int id = bankDB.getId(username, password);
		bankDB.close();
		if (id == 0) {
			request.setAttribute("username", username);
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		} else {
			request.getSession().setAttribute("id", id);
			request.getRequestDispatcher("GetBalances").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
