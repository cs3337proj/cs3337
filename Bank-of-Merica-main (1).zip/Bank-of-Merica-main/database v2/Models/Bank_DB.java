package Models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Bank_DB {
	private String host = "localhost";
	private String database = "cs3337";
	private String url = "jdbc:mysql://" + host + "/" + database;
	private String username = "root";
	private String password = "mysqldiv22";
	private Connection connection;
	
	public Bank_DB() {
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public boolean checkUsername(String username) {
		boolean check = false;
		try {
			int id = -1;
			String query = "SELECT id FROM Credentials WHERE Username = (?)";
			PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) { id = rs.getInt("id"); }
			ps.close();
			if (id != -1) { check = true; }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	public int addAccount(String firstname, String lastname, String address, String city, String state, String zip, String phone, String ssn, String username, String password) {
		Random r = new Random();
		int numID = r.nextInt(9999999 - 1) + 1;
		String id = String.valueOf(numID);
		String account = "INSERT INTO Accounts (account_id) values ( " + id + ")";
		String checking = "INSERT INTO Checking (Account_ID, balance) values (" + id + ", 0)";
		String savings = "INSERT INTO Savings (Account_ID, balance) values (" + id + ", 0)";
		String credentials = "INSERT INTO Credentials (id, username, password) values (" + id +", ?, ?)";
		String personal = "INSERT INTO Information (id, firstname, lastname, address, city, state, zip, phone, ssn) values (" + id + ", ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			try {
				connection.setAutoCommit(false);
				Statement stmt = connection.createStatement();
				stmt.executeUpdate(account);
				stmt.executeUpdate(checking);
				stmt.executeUpdate(savings);
				stmt.close();
				PreparedStatement ps1 = connection.prepareStatement(credentials, Statement.RETURN_GENERATED_KEYS);
				ps1.setString(1, username);
				ps1.setString(2, password);
				ps1.executeUpdate();
				ps1.close();
				PreparedStatement ps2 = connection.prepareStatement(personal, Statement.RETURN_GENERATED_KEYS);
				ps2.setString(1, firstname);
				ps2.setString(2, lastname);
				ps2.setString(3, address);
				ps2.setString(4, city);
				ps2.setString(5, state);
				ps2.setString(6, zip);
				ps2.setString(7, phone);
				ps2.setString(8, phone);
				ps2.executeUpdate();
				ps2.close();
				connection.commit();
			} catch (SQLException e) {
				connection.rollback();
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return numID;
	}
	
	public int getId(String username, String password) {
		int id = 0;
		try {
			String query = "SELECT id from Credentials where username = (?) and password = (?)";
			PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt("id");
			}
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public String getName(int id) {
		StringBuilder string = new StringBuilder();
		try {
			String query = "SELECT CONCAT(firstname, ' ', lastname) AS name FROM Information where id = " + id;
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				string.append(rs.getString("name"));
			}
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return string.toString();
	}
	
	public Information getInformation(int id) {
		Information entry = new Information();
		try {
			String query = "SELECT * FROM Information where id = " + id;
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				entry.setId(rs.getInt("id"));
				entry.setFirstname(rs.getString("firstname"));
				entry.setLastname(rs.getString("lastname"));
				entry.setAddress(rs.getString("address"));
				entry.setCity(rs.getString("city"));
				entry.setState(rs.getString("state"));
				entry.setZip(rs.getString("zip"));
				entry.setPhone(rs.getString("phone"));
				entry.setSsn(rs.getString("ssn"));
			}
			stmt.close();
		} catch (SQLException e) {
			e.addSuppressed(e);
		}
		return entry;
	}
	
	public void updateInformation(int id, String firstname, String lastname, String address, String city, String state, String zip, String phone) {
		try {
			try {
				connection.setAutoCommit(false);
				String query = "UPDATE Information SET firstname = (?), lastname = (?), address = (?), city = (?), state = (?), zip = (?), phone = (?) WHERE id = " + id;
				PreparedStatement ps = connection.prepareStatement(query);
				ps.setString(1, firstname);
				ps.setString(2, lastname);
				ps.setString(3, address);
				ps.setString(4, city);
				ps.setString(5, state);
				ps.setString(6, zip);
				ps.setString(7, phone);
				ps.executeUpdate();
				ps.close();
				connection.commit();
			} catch (SQLException e) {
				connection.rollback();
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Balance> getBalances(int id) {
		List<Balance> entries = new ArrayList<>();
		try {
			String checking = "SELECT id, balance FROM Checking where Account_id = " + String.valueOf(id);
			String savings = "SELECT id, balance FROM Savings where Account_ID = " + String.valueOf(id);
			Statement stmt = connection.createStatement();
			ResultSet check = stmt.executeQuery(checking);
			while (check.next()) {
				Balance entry = new Balance();
				entry.setId(check.getInt("id"));
				entry.setBalance(check.getInt("balance"));
				entry.setType("CHECKING");
				entries.add(entry);
			}
			ResultSet save = stmt.executeQuery(savings);
			while (save.next()) {
				Balance entry = new Balance();
				entry.setId(save.getInt("id"));
				entry.setBalance(save.getInt("balance"));
				entry.setType("SAVINGS");
				entries.add(entry);
			}
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return entries;
	}
	
	public Balance getBalance(int id, String type) {
		Balance entry = new Balance();
		try {
			String query = "SELECT id, balance from " + type + " WHERE id = " + String.valueOf(id);
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				entry.setId(rs.getInt("id"));
				entry.setBalance(rs.getInt("balance"));
				entry.setType(type);
			}
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return entry;
	}
	
	public void addBalance(int id, int oid, String oldType, String newType) {
		try {
			try {
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				LocalDateTime now = LocalDateTime.now();
				String date = dtf.format(now);
				String query = "INSERT INTO " + newType + " (Account_ID, balance) values ( " + id + ", 100)";
				String edit = "UPDATE " + oldType + " SET balance = balance - 100 where account_id = " + id + " and id = " + oid;
				String tran = "INSERT INTO Transactions (sender_id, account_id, reason, debit, credit, date, type) values (?, ?, ?, ?, ?, ?, ?)";
				connection.setAutoCommit(false);
				Statement stmt = connection.createStatement();
				stmt.executeUpdate(query);
				stmt.executeUpdate(edit);
				stmt.close();
				PreparedStatement ps = connection.prepareStatement(tran);
				ps.setInt(1, id);
				ps.setInt(2, oid);
				ps.setString(3, "Funds Transfer");
				ps.setInt(4, 100);
				ps.setInt(5, 0);
				ps.setString(6, date);
				ps.setString(7, oldType);
				ps.executeUpdate();
				ps.close();
				connection.commit();
			} catch (SQLException e) {
				connection.rollback();
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Transaction> getTransactions(int id, int accID, String type) {
		List<Transaction> entries = new ArrayList<>();
		try {
			String query = "select * from transactions where sender_id = (?) and account_id = (?) and type = (?)";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setInt(1, id);
			ps.setInt(2, accID);
			ps.setString(3, type);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Transaction entry = new Transaction();
				entry.setSenderID(rs.getInt("sender_id"));
				entry.setAccountID(rs.getInt("account_id"));
				entry.setReason(rs.getString("reason"));
				entry.setDebit(rs.getInt("debit"));
				entry.setCredit(rs.getInt("credit"));
				entry.setDate(rs.getString("date"));
				entry.setType(rs.getString("type"));
				entries.add(entry);
			}
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return entries;
	}
	
	public void transfer(String sender, String receiver) {
		
	}
	
}
